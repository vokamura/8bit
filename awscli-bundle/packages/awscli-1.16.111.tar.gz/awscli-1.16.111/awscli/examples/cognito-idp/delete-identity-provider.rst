**To delete an identity provider**

This example deletes an identity provider.

Command::

  aws cognito-idp delete-identity-provider --user-pool-id us-west-2_aaaaaaaaa --provider-name Facebook
  
